
	<div class="copy-right"> 
		<div class="container">
			<p>© 2024 KSRTC Bus Pass </p>
		</div> 
	</div> 
	<!-- //footer -->   
	